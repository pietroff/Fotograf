=== Photo Gallery Slideshow & Masonry Tiled Gallery ===
Contributors:nik00726
Donate link: http://www.i13websolution.com/donate-wordpress_image_thumbnail.php
Tags:wordpress responsive photo gallery,wordpress responsive gallery,wordpress responsive photo slideshow,wp responsive photo slideshow,Masonry Gallery,wordpress responsive photo album slideshow, Tiled Gallery
Requires at least:3.5
Tested up to:4.9
Version:1.0.3
Stable tag:1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is beautiful masonry tiled gallery and photo gallery slideshow plugin for wordPress blogs and sites.Admin can manages any number of images for photo slideshow and unlimited media into the masonry gallery.

== Description ==

WordPress Photo Gallery Slideshow & Masonry Tiled Gallery is beautiful masonry tiled gallery and photo gallery slideshow plugin for wordPress.Admin can manages any number of images for photo slideshow and unlimited media into the masonry gallery.

Admin can add,edit and delete photo gallery slideshow images and also mida for masonry gallery.Before add photo gallery slideshow and masonry gallery to wordPress blog admin can preview it.Admin can set settings like height,width many other settings.

**Find Photo Gallery Slideshow & Masonry Tiled Gallery Pro Plugin (Unlimited Photo slideshow and Masonry Tiled Galleries + Mass Image Upload + Much more fatures) at [WordPress Photo Gallery Slideshow & Masonry Tiled Gallery Pro Plugin](https://www.i13websolution.com/wordpress-responsive-photo-gallery-pro-plugin.html)**


**[Live Demo WordPress Masonry Tiled Gallery Pro](http://blog.i13websolution.com/masonry-tiled-gallery-wordpress-plugin)**

**[Live Demo WordPress Photo gallery Slideshow Pro](http://blog.i13websolution.com/wp-responsive-photo-gallery-pro/)**



**Masonry Tiled Gallery Video**

[youtube https://www.youtube.com/watch?v=kDKwHImBRyQ]


**Photo Gallery Slideshow Video**

[youtube https://www.youtube.com/watch?v=enYB1s1P8C0]


**Please rate this plugin if you find it useful**



**=Masonry Tiled Gallery Features=**

1. Add any number of media(image,video,links) into to masonry tiled gallery.

2. Masonry Tiled Gallery and lightbox both are responsive

3. Edit masonry tiled gallery media.

4. Preview your Masonry Tiled Gallery before use it.

5. Masonry Tiled Gallery installation into theme is simple just add shortcode to theme or pages/posts.

6. Changes to show/hide icons and caption is easy.

7. show media(image,video) to lightbox.


**=Masonry Tiled Gallery Pro Features=**

1. Unlimited Tiled Masonry gallery and lightbox(Multiple Tiled Masonry gallery).

2. Supported video types are custom html 5 video, Youtube,Vimeo, Metacafe, DailyMotion.

3. support pagination for tiled masonry gallery

4. Support media description into lightbox.

5. Support caption to the thumbnails.

6.Show hide caption is easy.

7. Show hide icons on hover is easy.'

8. New Field Added media Order, Now admin can display media according media order.

9. Responsive Admin Layout.

10.No advertisements.


**=Photo Gallery Slideshow Features=**

1. Add any number of images to responsive photo gallery slider.

2. Edit images and image name.

3. Preview your responsive photo gallery slider before use it.

5. Slider installation into theme is simple just add shortcode
to theme or pages/posts.

6. changes to images height,width

7. Changes to slider speed is easy.

8. Admin can set slider as slide with arrow left and right arrow.

9. Responsive Admin Layout.


**=Photo Gallery Slideshow Pro Version Features=**

1. Unlimited Photo Galleries(Multiple Photo Gallery).

2. Mass Images Upload Using WordPress Media Editor.

3. Use wordPress media uploader to upload image.

4. Add wordpress featured image in photo gallery directly from post/page add/edit.

5. Slider Easing Effects(select your desired slider easing effect ).

6. No advertisements.

7. If image description set it will added to image caption.

8. Now admin can display photo gallery according image order.

9. Open image link in new tab or same tab.

10. Display photo gallery with thumbnail caption.

11. Display slider image with caption(image with description).

12. Display tumbnail gallary to top,bottom.

13. Responsive Admin Layout.


[Get Support](http://www.i13websolution.com/contacts)


== Installation ==


This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. upload wp-responsive-photo-gallery folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use wordpress image slider.


### Usage ###

1.Use of Photo Gallery Slideshow & Masonry Tiled Gallery is easy after activating plugin go to Photo Slideshow & Masonry Gallery.

2.You can manage images by Manage Images/Manage Media menu.

3.You can set settings for this plugin using Slideshow & Masonry Tiled Gallery settings menu.

4.You can add this slider to your wordpress page/post by adding this shortcode to [print_my_responsive_photo_gallery]

OR you can add this to your theme by adding this code echo do_shortcode('[print_my_responsive_photo_gallery]'); to your theme


== Screenshots ==


1. Masonry Tiled Gallery Settings
2. Masonry Tiled Gallery Manage Media
3. Frontend Preview of Masonry Tiled Gallery
4. Masonry Tiled Gallery Pro Version (Unlimited Galleries)
5. Masonry Tiled Gallery Pro Version Add Media
6. Masonry Tiled Gallery Pro Version Frontend Preview
7. Photo Gallery Slideshow Settings
8. Photo Gallery Slideshow Manage Images
9. Photo Gallery Slideshow Pro Version (Unlimited Galleries)
10. Photo Gallery Slideshow Frontend Preview
11. Photo Gallery Slideshow Pro Manage Images
12. Photo Gallery Slideshow Pro Version Frontend Preview



== License ==


This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.


== Changelog ==

= 1.0.3 =

* Made plugin translatable

* Added new feature called "Masonry Tiled Gallery"


= 1.0.2 =

* Fixed shortcode not working in Wordpress 4.8

* Tested upto wordpress 4.8

= 1.0.1 =

* I notice that some host wan't allow url in copy function php so now it is fixed.

* Tested upto wordpress 4.6

= 1.0 =

* Stable 1.0 first release


== Upgrade notice ==


= 1.0.1 =

* Pro version please do not Upgrade here insted contact @ https://www.i13websolution.com/contacts


= 1.0 =

* Stable 1.0 first release




== Frequently asked questions ==

1.How to use ?

For More info use readme installation and usage notes.
